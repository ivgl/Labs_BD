db_params = {
    'host': 'localhost',
    'port': 5432,
    'user': 'postgres',
    'dbname': 'postgres',
    'password': '123'
}
